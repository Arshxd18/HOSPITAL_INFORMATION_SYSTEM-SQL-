Hospital Management System (SQL-Centric Project)
📌 Project Overview

This project is a database-driven Hospital Management System designed with a strong focus on MySQL architecture and advanced SQL concepts.
It consists of 28 fully normalized relational tables, supported by stored procedures, triggers, and views to ensure data integrity, automation, and analytical reporting.
A lightweight web application connects to the database via REST APIs to automate data insertion without exposing raw SQL.

🎯 Key Objectives

Design a real-world hospital database using relational modeling

Implement business logic at the database level

Generate analysis-ready data for Excel dashboards

Demonstrate secure automation using APIs and stored procedures

🗄️ Database Design

Total Tables: 28

Core Modules:

Patients

Doctors

Departments

Admissions & Discharges

Appointments

Visits

Billing & Payments

Lab Tests

Prescriptions

Wards & Beds

Database Features

✅ Fully normalized schema

✅ Foreign key constraints for data consistency

✅ Triggers for rule enforcement (availability, status updates)

✅ Stored procedures for all write operations

✅ Views for reporting and analytics

⚙️ Advanced SQL Implementation
Stored Procedures

admit_patient

discharge_patient

book_appointment

record_visit

generate_bill

make_payment

order_lab_test

create_prescription

All insert/update operations are executed only through stored procedures.

Views (Analytics & Reporting)

Admission status & current admissions

Bed and ward occupancy

Doctor workload

Daily appointments

Billing summaries

Payment methods

Monthly visits

Patient demographics & medical history

These views are exported directly to Excel for pivot tables and chart-based dashboards.

📊 Data Analysis & Dashboard

SQL Views used as reporting layers

Data exported to Excel

Pivot tables and charts created for:

Admissions trends

Doctor utilization

Revenue & billing insights

Ward occupancy rates

🌐 Automation Layer (API Integration)

A minimal web application is used to automate data flow:

Architecture
Frontend (React)
      ↓ JSON
REST API (Node.js + Express)
      ↓ CALL Stored Procedures
MySQL Database

Key Principles

No raw SQL exposed to frontend

APIs only invoke stored procedures

Database handles all business logic

🛠️ Tech Stack

Database: MySQL
Backend API: Node.js, Express
Frontend: React (Vite)
Data Analysis: Excel (Pivot Tables & Charts)
Tools: MySQL Workbench, VS Code

🚀 How to Run (Optional Automation)

Start MySQL Server

Import database schema and procedures

Configure .env file with DB credentials

Run backend server (node server.js)

Start frontend (npm run dev)

🎓 Academic Value

This project demonstrates:

Strong SQL fundamentals

Real-world database modeling

Automation using APIs

Analytical thinking with reporting

Industry-style architecture

Ideal for DBMS projects, internships, viva voce, and portfolio showcase.

📌 Author

Mohamed Arshad
Engineering Student | Data & Database Enthusiast
