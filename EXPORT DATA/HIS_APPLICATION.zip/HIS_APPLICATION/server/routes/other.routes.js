const express = require('express');
const router = express.Router();
const prescriptionController = require('../controllers/prescription.controller');
const billingController = require('../controllers/billing.controller');
const labController = require('../controllers/lab.controller');

// Prescription
router.post('/prescriptions', prescriptionController.createPrescription);

// Billing
router.post('/billing/generate', billingController.generateBill);
router.post('/billing/pay', billingController.makePayment);

// Lab
router.post('/labs/order', labController.orderLabTest);

// Dashboard Stats
const statsController = require('../controllers/stats.controller');
router.get('/dashboard/stats', statsController.getDashboardStats);

module.exports = router;
