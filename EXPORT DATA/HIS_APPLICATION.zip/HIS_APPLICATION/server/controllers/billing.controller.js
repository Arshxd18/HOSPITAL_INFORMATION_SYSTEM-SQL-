const { executeProcedure } = require('../utils/dbHelper');

exports.generateBill = async (req, res, next) => {
    try {
        const { admissionId } = req.body;
        const result = await executeProcedure('generate_bill', [admissionId]);
        res.status(200).json({ success: true, data: result[0] });
    } catch (error) {
        next(error);
    }
};

exports.makePayment = async (req, res, next) => {
    try {
        const { billId, amount, method } = req.body;
        const result = await executeProcedure('make_payment', [billId, amount, method]);
        res.status(200).json({ success: true, message: 'Payment successful', data: result[0] });
    } catch (error) {
        next(error);
    }
};
