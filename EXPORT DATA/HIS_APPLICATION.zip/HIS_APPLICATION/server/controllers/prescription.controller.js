const { executeProcedure } = require('../utils/dbHelper');

exports.createPrescription = async (req, res, next) => {
    try {
        const { visitId, medicines, instruction } = req.body;
        // medicines is expected to be an array or string depending on DB implementation.
        // Assuming the detailed SP handles it or we pass a JSON string.
        // For simplicity, let's assume the DB takes a JSON string or we iterate.
        // Given the prompt "Execute stored procedures", and "create_prescription", 
        // it likely takes a header or maybe we need to call `add_medicine_to_prescription` in a loop.
        // But let's assume a wrapper SP exists or we pass basic data.

        // Simplest approach: One procedure call per prescription Header, then items?
        // User requested "create_prescription", let's assume it does it all or just the header.

        const result = await executeProcedure('create_prescription', [
            visitId, JSON.stringify(medicines), instruction
        ]);

        res.status(201).json({
            success: true,
            message: 'Prescription created successfully',
            data: result[0]
        });
    } catch (error) {
        next(error);
    }
};
